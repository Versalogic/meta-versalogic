/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __IEEE802154_NL802154_H
#define __IEEE802154_NL802154_H

int nl802154_init(void);
void nl802154_exit(void);

#endif /* __IEEE802154_NL802154_H */
